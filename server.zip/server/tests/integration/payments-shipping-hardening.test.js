import { describe, it, expect, beforeAll, afterAll, afterEach, vi } from "vitest";
import mongoose from "mongoose";
import request from "supertest";
import app from "../../src/app.js";
import { Order } from "../../src/models/Order.js";
import { Payment } from "../../src/models/Payment.js";
import { Shipment } from "../../src/models/Shipment.js";
import { WebhookEvent } from "../../src/models/WebhookEvent.js";
import { Refund } from "../../src/models/Refund.js";
import { ProductVariant } from "../../src/models/ProductVariant.js";
import { Product } from "../../src/models/Product.js";
import { hmacSha256 } from "../../src/utils/crypto.js";
import { config } from "../../src/config/index.js";
import { ORDER_STATUS } from "../../src/constants/orderStatus.js";
import { PAYMENT_STATUS } from "../../src/constants/paymentStatus.js";
import { orderService } from "../../src/services/order.service.js";
import { shipmentService } from "../../src/services/shipment.service.js";
import { paymentService } from "../../src/services/payment.service.js";
import { adminService } from "../../src/services/admin.service.js";
import { inventoryService } from "../../src/services/inventory.service.js";
import { cashfree } from "../../src/integrations/cashfree/cashfree.adapter.js";
import { shiprocket } from "../../src/integrations/shiprocket/shiprocket.adapter.js";
import { ShiprocketAdapter } from "../../src/integrations/shiprocket/shiprocket.adapter.js";

const cfSecret = config.CASHFREE_SECRET_KEY || "TEST_CF_SECRET_KEY";
const srSecret = config.SHIPROCKET_WEBHOOK_SECRET || "test_shiprocket_webhook_secret_999";
const stamp = Date.now();

describe.sequential("Payment and shipping hardening", () => {
  let product;
  const created = { orders: [], variants: [], products: [] };
  let counter = 0;

  beforeAll(async () => {
    await Shipment.syncIndexes(); // an older test database may still hold the non-unique index
    // Reuse an existing product (like the other suites) so no test ever leaves variants pointing at a deleted one
    product = await Product.findOne();
    if (!product) {
      product = await Product.create({
        name: "Hardening Test Product",
        slug: `hardening-${stamp}`,
        sku: `HARD-${stamp}`,
        categoryId: "ayurvedic-herbs",
        status: "active",
        basePricePaise: 49900,
      });
      created.products.push(product._id);
    }
  });

  afterAll(async () => {
    const numbers = created.orders.map((o) => o.orderNumber);
    await Shipment.deleteMany({ orderNumber: { $in: numbers } });
    await Payment.deleteMany({ orderNumber: { $in: numbers } });
    await Refund.deleteMany({ orderNumber: { $in: numbers } });
    await WebhookEvent.deleteMany({ "rawPayload.data.order.order_id": { $in: numbers } });
    await Order.deleteMany({ orderNumber: { $in: numbers } });
    await ProductVariant.deleteMany({ _id: { $in: created.variants } });
    await Product.deleteMany({ _id: { $in: created.products } });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  /** A pending online order whose stock is reserved (the state a real checkout leaves it in) */
  const makeOrder = async ({ paymentMethod = "Online Payment", status = ORDER_STATUS.PENDING_PAYMENT, stock = 10, reserved = 1 } = {}) => {
    counter += 1;
    const variant = await ProductVariant.create({
      productId: product._id,
      sku: `HARD-V-${stamp}-${counter}`,
      label: `Pack ${counter}`,
      pricePaise: 49900,
      stockOnHand: stock,
      reservedStock: reserved,
      reorderThreshold: 2,
      isActive: true,
    });
    created.variants.push(variant._id);

    const order = await Order.create({
      orderNumber: `DA-HD-${stamp}-${counter}`,
      customer: { name: "Hardening Customer", email: "hardening@example.test", phone: "9876543210" },
      shippingAddress: { fullName: "Hardening Customer", phone: "9876543210", street: "1 Test Street", city: "Bengaluru", state: "Karnataka", pincode: "560001" },
      items: [
        { productId: product._id, variantId: variant._id, sku: variant.sku, name: "Hardening Test Product", size: variant.label, unitPricePaise: 49900, quantity: 1, lineTotalPaise: 49900, weightGrams: 250 },
      ],
      pricing: { subtotalPaise: 59900, couponDiscountPaise: 10000, shippingPaise: 5000, totalPaise: 54900 },
      paymentMethod,
      status,
      stockState: "reserved",
      paymentStatus: PAYMENT_STATUS.PENDING,
      timeline: [{ status: "Order Placed", time: new Date(), completed: true }],
    });
    created.orders.push(order);
    return { order, variant };
  };

  const postCashfree = (payload, { eventId = `evt_${Date.now()}_${Math.random()}` } = {}) => {
    const rawBody = JSON.stringify(payload);
    const timestamp = Date.now().toString();
    return request(app)
      .post("/api/v1/webhooks/cashfree")
      .set("x-webhook-signature", hmacSha256(`${timestamp}${rawBody}`, cfSecret))
      .set("x-webhook-timestamp", timestamp)
      .set("x-webhook-id", eventId)
      .set("Content-Type", "application/json")
      .send(rawBody);
  };

  const paymentPayload = (orderNumber, status, id = "cf_pay_1", amount = 549) => ({
    type: status === "SUCCESS" ? "PAYMENT_SUCCESS_WEBHOOK" : "PAYMENT_FAILED_WEBHOOK",
    data: { order: { order_id: orderNumber }, payment: { cf_payment_id: id, payment_status: status, payment_amount: amount } },
  });

  describe("Cashfree webhook", () => {
    it("deducts stock exactly once when the same payment is delivered concurrently", async () => {
      const { order, variant } = await makeOrder();
      const payload = paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_race");

      const results = await Promise.all([1, 2, 3].map((n) => postCashfree(payload, { eventId: `race_${stamp}_${n}` })));
      results.forEach((res) => expect([200, 400, 500]).toContain(res.status));

      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.status).toBe(ORDER_STATUS.CONFIRMED);
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED);
      expect(fresh.stockState).toBe("committed");

      const stock = await ProductVariant.findById(variant._id);
      expect(stock.stockOnHand).toBe(9);
      expect(stock.reservedStock).toBe(0);
    });

    it("does not deduct stock a second time when the paid order is later delivered", async () => {
      const { order, variant } = await makeOrder();
      expect((await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_deliver"))).status).toBe(200);

      await orderService.updateOrderStatus(order.orderNumber, ORDER_STATUS.DELIVERED, "Delivered");

      const stock = await ProductVariant.findById(variant._id);
      expect(stock.stockOnHand).toBe(9);
      expect(stock.reservedStock).toBe(0);
    });

    it("ignores a late FAILED attempt once the order is paid", async () => {
      const { order } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_ok"));
      const res = await postCashfree(paymentPayload(order.orderNumber, "FAILED", "cf_pay_old_attempt"));
      expect(res.status).toBe(200);

      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED);
      expect(fresh.status).toBe(ORDER_STATUS.CONFIRMED);
    });

    it("marks an unpaid order failed on a FAILED event but lets a later success win", async () => {
      const { order, variant } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "FAILED", "cf_pay_try1"));
      expect((await Order.findOne({ orderNumber: order.orderNumber })).paymentStatus).toBe(PAYMENT_STATUS.FAILED);

      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_try2"));
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED);
      expect(fresh.status).toBe(ORDER_STATUS.CONFIRMED);
      expect((await ProductVariant.findById(variant._id)).stockOnHand).toBe(9);
    });

    it("re-processes an event that failed earlier instead of failing forever", async () => {
      const { order } = await makeOrder();
      const payload = paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_retry");
      const eventId = `retry_${stamp}`;
      await WebhookEvent.create({
        provider: "cashfree",
        eventId,
        eventType: payload.type,
        payloadHash: "previous-attempt-hash",
        rawPayload: payload,
        status: "failed",
        error: "temporary database error",
      });

      const res = await postCashfree(payload, { eventId });
      expect(res.status).toBe(200);
      expect(res.body.result.status).toBe("processed");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED);
    });

    it("ignores events that carry no payment status (settlements, disputes)", async () => {
      const { order } = await makeOrder();
      const res = await postCashfree({ type: "SETTLEMENT_WEBHOOK", data: { order: { order_id: order.orderNumber }, settlement: { status: "DONE" } } });
      expect(res.status).toBe(200);
      expect(res.body.result.status).toBe("ignored");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).paymentStatus).toBe(PAYMENT_STATUS.PENDING);
    });

    it("rejects a payment whose amount differs from the order total", async () => {
      const { order } = await makeOrder();
      const res = await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_wrong", 1));
      expect(res.status).toBe(400);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).paymentStatus).toBe(PAYMENT_STATUS.PENDING);
    });

    it("serves the payment status route the storefront calls", async () => {
      const res = await request(app).get("/api/v1/payments/cashfree/orders/DA-DOES-NOT-EXIST/status");
      expect(res.status).toBe(404);
      expect(res.body.error.message).toMatch(/order not found/i);
    });
  });

  describe("Cancelling orders", () => {
    it("puts stock back when a paid order is cancelled", async () => {
      const { order, variant } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_cancel"));
      expect((await ProductVariant.findById(variant._id)).stockOnHand).toBe(9);

      await orderService.cancelOrder(order.orderNumber, "Customer changed mind");

      const stock = await ProductVariant.findById(variant._id);
      expect(stock.stockOnHand).toBe(10);
      expect(stock.reservedStock).toBe(0);
    });

    it("just un-reserves stock when an unpaid order is cancelled", async () => {
      const { order, variant } = await makeOrder();
      await orderService.cancelOrder(order.orderNumber, "Never paid");
      const stock = await ProductVariant.findById(variant._id);
      expect(stock.stockOnHand).toBe(10);
      expect(stock.reservedStock).toBe(0);
    });
  });

  describe("Cancellation side effects", () => {
    const staff = () => ({ _id: new mongoose.Types.ObjectId(), name: "Test Staff", roles: [] });

    it("refunds a paid online order to the original payment method, once", async () => {
      const { order } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_refund"));

      await orderService.cancelOrder(order.orderNumber, "Customer request", staff());

      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.status).toBe(ORDER_STATUS.CANCELLED);
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.REFUNDED);
      expect(fresh.refundedPaise).toBe(54900);
      const refunds = await Refund.find({ orderNumber: order.orderNumber });
      expect(refunds).toHaveLength(1);
      expect(refunds[0].amountPaise).toBe(54900);
      expect(refunds[0].status).toBe("succeeded");
    });

    it("does not refund an order that was never paid", async () => {
      const { order } = await makeOrder();
      await orderService.cancelOrder(order.orderNumber, "Never paid", staff());
      expect(await Refund.countDocuments({ orderNumber: order.orderNumber })).toBe(0);
    });

    it("cancels the courier booking together with the order", async () => {
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.DISPATCHED });
      await Shipment.create({ orderId: order._id, orderNumber: order.orderNumber, awbCode: `AWB-CX-${stamp}-${counter}`, status: "SHIPPED" });
      const spy = vi.spyOn(shiprocket, "cancelShipment").mockResolvedValue({ success: true });

      await orderService.updateOrderStatus(order.orderNumber, "Cancelled", "Customer request", staff());

      expect(spy).toHaveBeenCalledTimes(1);
      expect((await Shipment.findOne({ orderNumber: order.orderNumber })).status).toBe("CANCELLED");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.CANCELLED);
    });

    it("keeps the order open when Shiprocket refuses to cancel the shipment", async () => {
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.DISPATCHED });
      await Shipment.create({ orderId: order._id, orderNumber: order.orderNumber, awbCode: `AWB-CY-${stamp}-${counter}`, status: "SHIPPED" });
      vi.spyOn(shiprocket, "cancelShipment").mockResolvedValue({ success: false, message: "Already picked up" });

      await expect(orderService.cancelOrder(order.orderNumber, "Too late", staff())).rejects.toThrow(/did not cancel/i);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.DISPATCHED);
    });
  });

  describe("Refunds that are still pending after a cancellation", () => {
    const staff = () => ({ _id: new mongoose.Types.ObjectId(), name: "Test Staff", roles: [] });

    const cancelPaidWithPendingRefund = async () => {
      const { order } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", `cf_pay_pr_${counter}`));
      vi.spyOn(cashfree, "createRefund").mockResolvedValue({ refundId: "x", cfRefundId: "cf_rf_1", status: "PENDING" });
      await orderService.cancelOrder(order.orderNumber, "Customer request", staff());
      vi.restoreAllMocks();
      const refund = await Refund.findOne({ orderNumber: order.orderNumber });
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(refund.status).toBe("pending");
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED); // not "refunded" until Cashfree confirms
      expect(fresh.refundedPaise).toBe(54900);
      return { order, refund };
    };

    const refundEvent = (order, refund, status) => ({
      type: "REFUND_STATUS_WEBHOOK",
      data: { refund: { refund_id: refund.refundId, order_id: order.orderNumber, cf_refund_id: "cf_rf_1", refund_status: status, refund_amount: 549 } },
    });

    it("marks the order refunded when Cashfree's refund webhook reports success", async () => {
      const { order, refund } = await cancelPaidWithPendingRefund();
      const res = await postCashfree(refundEvent(order, refund, "SUCCESS"));
      expect(res.status).toBe(200);

      expect((await Refund.findById(refund._id)).status).toBe("succeeded");
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.REFUNDED);
      expect(fresh.timeline.some((t) => t.status === "Refund completed")).toBe(true);

      // the same event again changes nothing
      await postCashfree(refundEvent(order, refund, "SUCCESS"));
      expect(fresh.refundedPaise).toBe(54900);
    });

    it("flags the order for a manual refund when Cashfree reports the refund failed", async () => {
      const { order, refund } = await cancelPaidWithPendingRefund();
      await postCashfree(refundEvent(order, refund, "FAILED"));

      expect((await Refund.findById(refund._id)).status).toBe("failed");
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.refundedPaise).toBe(0);
      expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED);
      expect(fresh.timeline.some((t) => t.status === "Refund failed")).toBe(true);
    });

    it("finishes a pending refund by asking Cashfree when no webhook arrived", async () => {
      const { order, refund } = await cancelPaidWithPendingRefund();
      await Refund.collection.updateOne({ _id: refund._id }, { $set: { createdAt: new Date(Date.now() - 60 * 60 * 1000) } });

      const result = await paymentService.syncPendingCancelRefunds();
      expect(result.updated).toBeGreaterThanOrEqual(1);
      expect((await Refund.findById(refund._id)).status).toBe("succeeded");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).paymentStatus).toBe(PAYMENT_STATUS.REFUNDED);
    });
  });

  describe("Automatic shipment creation", () => {
    const waitFor = async (check, ms = 2000) => {
      const end = Date.now() + ms;
      while (Date.now() < end) {
        const value = await check();
        if (value) return value;
        await new Promise((r) => setTimeout(r, 25));
      }
      return null;
    };

    const live = () => {
      const original = shiprocket.isMock;
      shiprocket.isMock = false;
      return () => {
        shiprocket.isMock = original;
      };
    };

    it("books the courier as soon as an online payment is confirmed", async () => {
      const restore = live();
      try {
        const spy = vi.spyOn(shiprocket, "createShipment").mockResolvedValue({
          shiprocketOrderId: "sr-auto", shipmentId: "ship-auto", awbCode: `AWB-AUTO-${stamp}`, courierName: "Delhivery",
          courierId: "5", trackingUrl: "https://t/x", labelUrl: "https://l/x.pdf", status: "AWB_ASSIGNED",
        });
        const { order } = await makeOrder();
        await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_auto"));

        const shipment = await waitFor(() => Shipment.findOne({ orderNumber: order.orderNumber, awbCode: { $exists: true } }));
        expect(shipment?.awbCode).toBe(`AWB-AUTO-${stamp}`);
        expect(spy).toHaveBeenCalledTimes(1);
        const dispatched = await waitFor(async () => (await Order.findOne({ orderNumber: order.orderNumber })).status === ORDER_STATUS.DISPATCHED);
        expect(dispatched).toBe(true);
      } finally {
        restore();
      }
    });

    it("never touches the courier while the mock adapter is in use", async () => {
      const spy = vi.spyOn(shiprocket, "createShipment");
      const { order } = await makeOrder();
      await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_nomock"));
      await new Promise((r) => setTimeout(r, 150));
      expect(spy).not.toHaveBeenCalled();
      expect(await Shipment.countDocuments({ orderNumber: order.orderNumber })).toBe(0);
    });

    it("leaves a note for staff instead of failing when Shiprocket rejects the order", async () => {
      const restore = live();
      try {
        vi.spyOn(shiprocket, "createShipment").mockRejectedValue(new Error("Pickup location not found."));
        const { order } = await makeOrder();
        await postCashfree(paymentPayload(order.orderNumber, "SUCCESS", "cf_pay_autofail"));

        const flagged = await waitFor(async () => {
          const o = await Order.findOne({ orderNumber: order.orderNumber });
          return o.timeline.find((t) => t.status === "Automatic dispatch needs attention");
        });
        expect(flagged?.note).toMatch(/Pickup location not found/);
        const fresh = await Order.findOne({ orderNumber: order.orderNumber });
        expect(fresh.paymentStatus).toBe(PAYMENT_STATUS.SUCCEEDED); // the payment itself is unaffected
        expect(fresh.status).toBe(ORDER_STATUS.CONFIRMED);
      } finally {
        restore();
      }
    });
  });

  describe("Shiprocket tracking webhook", () => {
    const sendTracking = (payload) => request(app).post("/api/v1/webhooks/shiprocket").set("x-api-key", srSecret).send(payload);

    const makeShippedOrder = async () => {
      const { order, variant } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.DISPATCHED, reserved: 1 });
      const awb = `AWB-HD-${stamp}-${counter}`;
      await Shipment.create({ orderId: order._id, orderNumber: order.orderNumber, awbCode: awb, courierName: "Delhivery", status: "SHIPPED" });
      return { order, variant, awb };
    };

    it("maps statuses with spaces and never moves a delivered order backwards", async () => {
      const { order, variant, awb } = await makeShippedOrder();

      expect((await sendTracking({ awb, current_status: "OUT FOR DELIVERY", current_timestamp: "2026-10-31 10:00:00" })).status).toBe(200);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.OUT_FOR_DELIVERY);

      await sendTracking({ awb, current_status: "DELIVERED", current_timestamp: "2026-10-31 15:00:00" });
      const delivered = await Order.findOne({ orderNumber: order.orderNumber });
      expect(delivered.status).toBe(ORDER_STATUS.DELIVERED);
      expect(delivered.stockState).toBe("committed");
      expect((await ProductVariant.findById(variant._id)).stockOnHand).toBe(9);

      await sendTracking({ awb, current_status: "IN TRANSIT", current_timestamp: "2026-10-31 09:00:00" });
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.DELIVERED);
    });

    it("records return-to-origin without changing the order status", async () => {
      const { order, awb } = await makeShippedOrder();
      await sendTracking({ awb, current_status: "RTO INITIATED", current_timestamp: "2026-10-31 12:00:00" });
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.status).toBe(ORDER_STATUS.DISPATCHED);
      expect(fresh.timeline.some((t) => t.status === "Returning to origin")).toBe(true);
    });

    it("rejects a request with the wrong token", async () => {
      const res = await request(app).post("/api/v1/webhooks/shiprocket").set("x-api-key", "wrong").send({ awb: "x", current_status: "DELIVERED" });
      expect(res.status).toBe(401);
    });
  });

  describe("Shipment creation", () => {
    it("creates only one shipment when dispatch is triggered twice at once", async () => {
      const { order } = await makeOrder({ status: ORDER_STATUS.CONFIRMED });
      const results = await Promise.allSettled([
        shipmentService.createShipmentForOrder(order.orderNumber),
        shipmentService.createShipmentForOrder(order.orderNumber),
      ]);
      expect(results.some((r) => r.status === "fulfilled")).toBe(true);
      expect(await Shipment.countDocuments({ orderNumber: order.orderNumber })).toBe(1);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.DISPATCHED);
    });

    it("does not mark an order dispatched when no courier could be assigned", async () => {
      const { order } = await makeOrder({ status: ORDER_STATUS.CONFIRMED });
      const { shiprocket } = await import("../../src/integrations/shiprocket/shiprocket.adapter.js");
      vi.spyOn(shiprocket, "createShipment").mockResolvedValue({
        orderNumber: order.orderNumber,
        shiprocketOrderId: "sr-1",
        shipmentId: "ship-1",
        awbCode: null,
        courierName: "",
        status: "PROCESSING",
      });

      await expect(shipmentService.createShipmentForOrder(order.orderNumber)).rejects.toThrow(/no courier/i);
      const fresh = await Order.findOne({ orderNumber: order.orderNumber });
      expect(fresh.status).toBe(ORDER_STATUS.CONFIRMED);
      const shipment = await Shipment.findOne({ orderNumber: order.orderNumber });
      expect(shipment.status).toBe("PROCESSING");
      expect(shipment.awbCode).toBeFalsy();
    });
  });

  describe("Stage A/B: what customers can see, the webhook alias, delivery checks, pickup and cancel", () => {
    const staff = () => ({ _id: new mongoose.Types.ObjectId(), name: "Staff", roles: [] });

    const withShipment = async (extra = {}) => {
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.DISPATCHED, reserved: 1 });
      const awb = `AWB-S2-${stamp}-${counter}`;
      await Order.updateOne({ _id: order._id }, { shippingLabelUrl: "https://labels.example/secret-label.pdf", trackingNumber: awb, carrier: "Delhivery" });
      const shipment = await Shipment.create({
        orderId: order._id,
        orderNumber: order.orderNumber,
        awbCode: awb,
        courierName: "Delhivery",
        shiprocketOrderId: `SR-ORD-${counter}`,
        shipmentId: `SR-SHIP-${counter}`,
        labelUrl: "https://labels.example/secret-label.pdf",
        status: "SHIPPED",
        trackingEvents: [{ status: "PICKED_UP", activity: "Picked up", location: "Pune" }],
        ...extra,
      });
      return { order, shipment, awb };
    };

    it("S2: a signed-out visitor with only the order number gets nothing", async () => {
      const { order } = await withShipment();
      const res = await request(app).get(`/api/v1/orders/${order.orderNumber}`);
      expect(res.status).toBe(404);
      const body = JSON.stringify(res.body);
      expect(body).not.toContain("secret-label");
      expect(body).not.toContain("Hardening Customer");
    });

    it("S2: private tracking (tracking code) hides the label and Shiprocket ids", async () => {
      const { order, awb } = await withShipment();
      const { trackingCode } = await orderService.regenerateTrackingCode(order.orderNumber, staff());
      const res = await request(app).post("/api/v1/orders/track").send({ code: trackingCode, orderNumber: order.orderNumber });
      expect(res.status).toBe(200);
      const body = JSON.stringify(res.body);
      expect(body).not.toContain("secret-label");
      expect(body).not.toContain("SR-ORD-");
      expect(body).not.toContain("SR-SHIP-");
      expect(res.body.data.shipment.awbCode).toBe(awb);
      expect(res.body.data.shipment.trackingEvents).toHaveLength(1);
    });

    it("private tracking does not repeat the street address, the full phone number or the email", async () => {
      const { order } = await withShipment();
      const { trackingCode } = await orderService.regenerateTrackingCode(order.orderNumber, staff());
      const res = await request(app).post("/api/v1/orders/track").send({ code: trackingCode });
      expect(res.status).toBe(200);
      expect(res.body.data.customer.phone).toBe("******3210");
      expect(res.body.data.customer.email).not.toContain("hardening@");
      expect(res.body.data.shippingAddress).toEqual({ city: "Bengaluru", state: "Karnataka", pincode: "560001" });
      expect(JSON.stringify(res.body)).not.toContain("1 Test Street");
    });

    it("S3: the neutral /webhooks/courier path takes the same tracking events, with the same token check", async () => {
      const { order, awb } = await withShipment();
      const bad = await request(app).post("/api/v1/webhooks/courier").set("x-api-key", "wrong").send({ awb, current_status: "DELIVERED" });
      expect(bad.status).toBe(401);
      const ok = await request(app)
        .post("/api/v1/webhooks/courier")
        .set("x-api-key", srSecret)
        .send({ awb, current_status: "OUT FOR DELIVERY", current_timestamp: "2026-11-01 10:00:00" });
      expect(ok.status).toBe(200);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.OUT_FOR_DELIVERY);
    });

    it("S4: refuses an order to a PIN code the courier cannot deliver to, but lets a courier outage through", async () => {
      vi.spyOn(shiprocket, "checkServiceability").mockResolvedValue({ serviceable: false });
      await expect(shipmentService.assertDeliverable({ pincode: "999991", cod: false })).rejects.toThrow(/can't deliver to PIN code 999991/);

      vi.restoreAllMocks();
      vi.spyOn(shiprocket, "checkServiceability").mockRejectedValue(new Error("Shiprocket is down"));
      await expect(shipmentService.assertDeliverable({ pincode: "999992", cod: false })).resolves.toBeUndefined();
    });

    it("S4: says so when only Cash on Delivery is unavailable for a PIN code", async () => {
      vi.spyOn(shiprocket, "checkServiceability").mockImplementation(async ({ cod }) => ({ serviceable: !cod }));
      await expect(shipmentService.assertDeliverable({ pincode: "999993", cod: true })).rejects.toThrow(/Cash on Delivery is not available/);
    });

    it("S6: remembers a failed pickup and lets staff retry just the pickup and the label", async () => {
      const { order, shipment } = await withShipment({ labelUrl: "", pickupStatus: "failed", pickupError: "Pickup address not verified", labelError: "No label yet" });
      await Order.updateOne({ _id: order._id }, { $unset: { shippingLabelUrl: 1 } });
      const pickup = vi.spyOn(shiprocket, "requestPickup").mockResolvedValue({});
      const label = vi.spyOn(shiprocket, "generateLabel").mockResolvedValue("https://labels.example/new.pdf");

      const result = await shipmentService.retryFulfilment(order.orderNumber, staff());
      expect(pickup).toHaveBeenCalledTimes(1);
      expect(label).toHaveBeenCalledTimes(1);
      expect(result.shipment.pickupStatus).toBe("requested");
      expect(result.shipment.pickupError).toBe("");
      expect((await Shipment.findById(shipment._id)).labelUrl).toBe("https://labels.example/new.pdf");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).shippingLabelUrl).toBe("https://labels.example/new.pdf");

      // nothing is asked of Shiprocket twice once both steps are done
      await shipmentService.retryFulfilment(order.orderNumber);
      expect(pickup).toHaveBeenCalledTimes(1);
      expect(label).toHaveBeenCalledTimes(1);
    });

    it("S6: keeps the reason when the retry fails again, and refuses a shipment with no courier yet", async () => {
      const { order } = await withShipment({ labelUrl: "", pickupStatus: "failed" });
      vi.spyOn(shiprocket, "requestPickup").mockRejectedValue(new Error("Still not serviceable"));
      vi.spyOn(shiprocket, "generateLabel").mockRejectedValue(new Error("Label not ready"));
      const result = await shipmentService.retryFulfilment(order.orderNumber);
      expect(result.shipment.pickupStatus).toBe("failed");
      expect(result.shipment.pickupError).toBe("Still not serviceable");
      expect(result.shipment.labelError).toBe("Label not ready");

      const { order: noAwb } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.CONFIRMED });
      await Shipment.create({ orderId: noAwb._id, orderNumber: noAwb.orderNumber, status: "PROCESSING", shipmentId: "SR-X", shiprocketOrderId: "SR-Y" });
      await expect(shipmentService.retryFulfilment(noAwb.orderNumber)).rejects.toThrow(/no courier assigned/i);
    });

    it("S6: the retry route needs a signed-in staff member", async () => {
      const res = await request(app).post("/api/v1/admin/orders/DA-NOPE/shipments/retry-fulfilment");
      expect(res.status).toBe(401);
    });

    it("S7: cancelling also cancels the Shiprocket order, even when no courier was assigned yet", async () => {
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.CONFIRMED });
      await Shipment.create({ orderId: order._id, orderNumber: order.orderNumber, status: "PROCESSING", shipmentId: "SR-S", shiprocketOrderId: "SR-ORDER-77" });
      const cancelAwb = vi.spyOn(shiprocket, "cancelShipment").mockResolvedValue({ success: true });
      const cancelOrder = vi.spyOn(shiprocket, "cancelOrder").mockResolvedValue({ success: true });

      await orderService.cancelOrder(order.orderNumber, "Customer request", staff());

      expect(cancelAwb).not.toHaveBeenCalled(); // no AWB existed
      expect(cancelOrder).toHaveBeenCalledWith("SR-ORDER-77");
      expect((await Shipment.findOne({ orderNumber: order.orderNumber })).status).toBe("CANCELLED");
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.CANCELLED);
    });

    it("S7: keeps the order open when Shiprocket will not cancel its order", async () => {
      const { order } = await withShipment();
      vi.spyOn(shiprocket, "cancelShipment").mockResolvedValue({ success: true });
      vi.spyOn(shiprocket, "cancelOrder").mockResolvedValue({ success: false, message: "Order already picked up" });
      await expect(orderService.cancelOrder(order.orderNumber, "Too late")).rejects.toThrow(/did not cancel its order/i);
      expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.DISPATCHED);
    });
  });

  describe("Stock never goes negative", () => {
    // Writes around the schema, the way old data got into this state
    const forceReserved = (variantId, value) => ProductVariant.collection.updateOne({ _id: variantId }, { $set: { reservedStock: value } });

    it("releasing or selling more than is reserved stops at zero instead of going negative", async () => {
      const { variant } = await makeOrder({ stock: 5, reserved: 1 });
      const line = [{ variantId: variant._id, productId: product._id, sku: variant.sku, quantity: 3 }];
      await inventoryService.releaseReservedStock(line, "DA-NEG-1");
      expect((await ProductVariant.findById(variant._id)).reservedStock).toBe(0);

      await inventoryService.commitSoldStock([{ ...line[0], quantity: 2 }], "DA-NEG-2");
      const after = await ProductVariant.findById(variant._id);
      expect(after.reservedStock).toBe(0);
      expect(after.stockOnHand).toBe(3);
    });

    // A product of its own with one pack size, so "set to N" is about exactly that pack
    const withSoloProduct = async (fn) => {
      const solo = await Product.create({ name: `Solo ${stamp}-${Math.random()}`, slug: `solo-${stamp}-${Math.random().toString(36).slice(2, 8)}`, sku: `SOLO-${stamp}-${Math.random().toString(36).slice(2, 8)}`, categoryId: "ayurvedic-herbs", status: "active", basePricePaise: 10000 });
      const variant = await ProductVariant.create({ productId: solo._id, sku: `${solo.sku}-V`, label: "Pack", pricePaise: 10000, stockOnHand: 2, reservedStock: 0, isActive: true });
      try {
        await fn(solo, variant);
      } finally {
        await ProductVariant.deleteMany({ productId: solo._id });
        await Product.deleteOne({ _id: solo._id });
      }
    };

    it("an admin 'set exactly' adjustment works on a variant that already has a negative reservation", () =>
      withSoloProduct(async (solo, variant) => {
        await forceReserved(variant._id, -2); // available looks like 4 although only 2 exist

        const result = await inventoryService.adjustProductStock({ productId: solo._id, operation: "set", quantity: 2, reason: "Test" });
        const fixed = await ProductVariant.findById(variant._id);
        expect(fixed.reservedStock).toBe(0);
        expect(fixed.stockOnHand).toBe(2);
        expect(result.stockQuantity).toBe(2);
      }));

    it("changing the number on a variant with a negative reservation removes or adds real stock only", () =>
      withSoloProduct(async (solo, variant) => {
        await forceReserved(variant._id, -2);
        await inventoryService.adjustProductStock({ productId: solo._id, operation: "deduct", quantity: 1, reason: "Test" });
        const after = await ProductVariant.findById(variant._id);
        expect(after.reservedStock).toBe(0);
        expect(after.stockOnHand).toBe(1);
      }));
  });

  describe("Stage C: tracking check, manual AWB guard, parcel details", () => {
    const live = () => {
      const original = shiprocket.isMock;
      shiprocket.isMock = false;
      return () => {
        shiprocket.isMock = original;
      };
    };

    const makeShipped = async (extra = {}) => {
      const { order, variant } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.DISPATCHED, reserved: 1 });
      const awb = `AWB-C-${stamp}-${counter}`;
      const shipment = await Shipment.create({
        orderId: order._id, orderNumber: order.orderNumber, awbCode: awb, courierName: "Delhivery",
        shipmentId: `SR-C-${counter}`, shiprocketOrderId: `SR-ORD-C-${counter}`, status: "SHIPPED", ...extra,
      });
      return { order, variant, shipment, awb };
    };

    const liveAnswer = (status, date = "2026-11-02 18:00:00") => ({
      shipment_track: [{ current_status: status }],
      shipment_track_activities: [{ date, status, activity: `Courier says ${status}`, location: "Pune" }],
    });

    it("the scheduled check moves an order to delivered (and sells the stock) when the webhook never came", async () => {
      const restore = live();
      try {
        const { order, variant, shipment, awb } = await makeShipped();
        vi.spyOn(shiprocket, "trackShipment").mockResolvedValue(liveAnswer("Delivered"));

        const result = await shipmentService.syncOpenShipments({ limit: 200 });
        expect(result.checked).toBeGreaterThanOrEqual(1);

        const fresh = await Order.findOne({ orderNumber: order.orderNumber });
        expect(fresh.status).toBe(ORDER_STATUS.DELIVERED);
        expect(fresh.stockState).toBe("committed");
        expect((await ProductVariant.findById(variant._id)).stockOnHand).toBe(9);
        const sh = await Shipment.findById(shipment._id);
        expect(sh.status).toBe("DELIVERED");
        expect(sh.lastSyncedAt).toBeTruthy();
        expect(sh.trackingEvents.some((e) => e.activity === "Courier says Delivered")).toBe(true);
        expect(awb).toBeTruthy();
      } finally {
        restore();
      }
    });

    it("the scheduled check skips finished and recently-read shipments, and never runs on the mock courier", async () => {
      const restore = live();
      try {
        const spy = vi.spyOn(shiprocket, "trackShipment").mockResolvedValue(liveAnswer("In Transit"));
        const done = await makeShipped({ status: "DELIVERED" });
        const fresh = await makeShipped({ lastSyncedAt: new Date() });
        await shipmentService.syncOpenShipments({ limit: 200 });
        const asked = spy.mock.calls.map((c) => c[0]);
        expect(asked).not.toContain(done.awb);
        expect(asked).not.toContain(fresh.awb);
      } finally {
        restore();
      }

      const mockSpy = vi.spyOn(shiprocket, "trackShipment");
      expect(await shipmentService.syncOpenShipments()).toMatchObject({ checked: 0 });
      expect(mockSpy).not.toHaveBeenCalled();
    });

    it("the scheduled check never moves a delivered order backwards and records scans only once", async () => {
      const restore = live();
      try {
        const { order, shipment } = await makeShipped();
        const track = vi.spyOn(shiprocket, "trackShipment").mockResolvedValue(liveAnswer("Delivered"));
        await shipmentService.syncShipment(await Shipment.findById(shipment._id));

        track.mockResolvedValue(liveAnswer("In Transit", "2026-11-02 08:00:00"));
        await shipmentService.syncShipment(await Shipment.findById(shipment._id));
        await shipmentService.syncShipment(await Shipment.findById(shipment._id));

        expect((await Order.findOne({ orderNumber: order.orderNumber })).status).toBe(ORDER_STATUS.DELIVERED);
        const sh = await Shipment.findById(shipment._id);
        expect(sh.status).toBe("DELIVERED");
        expect(sh.trackingEvents.filter((e) => e.activity === "Courier says In Transit")).toHaveLength(1);
      } finally {
        restore();
      }
    });

    it("refuses to change an AWB that Shiprocket assigned, but still lets staff fix the courier name and link", async () => {
      const { order, awb } = await makeShipped();
      await expect(shipmentService.updateCustomTracking(order.orderNumber, { trackingNumber: "SOMETHING-ELSE" })).rejects.toThrow(/assigned by Shiprocket/);

      const ok = await shipmentService.updateCustomTracking(order.orderNumber, { carrier: "Delhivery Surface", trackingNumber: awb, trackingUrl: "https://track.example/1" });
      expect(ok.carrier).toBe("Delhivery Surface");
      expect((await Shipment.findOne({ orderNumber: order.orderNumber })).awbCode).toBe(awb);
    });

    it("lets staff edit the AWB of a simulator shipment", async () => {
      const { order } = await makeShipped({ shiprocketOrderId: `sr_ord_${Date.now()}` });
      const updated = await shipmentService.updateCustomTracking(order.orderNumber, { trackingNumber: "MANUAL-123" });
      expect(updated.trackingNumber).toBe("MANUAL-123");
    });

    it("sends the courier each product's packed weight and box size, stacking units", async () => {
      const spy = vi.spyOn(shiprocket, "createShipment").mockResolvedValue({
        shiprocketOrderId: "sr-p", shipmentId: "ship-p", awbCode: `AWB-P-${stamp}`, courierName: "Delhivery", courierId: "5", trackingUrl: "", labelUrl: "", pickupRequested: true,
      });
      const original = await Product.findById(product._id).select("parcel").lean();
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.CONFIRMED });
      await Order.updateOne({ _id: order._id }, { $set: { "items.0.quantity": 2 } });
      await Product.updateOne({ _id: product._id }, { $set: { parcel: { weightGrams: 400, lengthCm: 12, breadthCm: 8, heightCm: 6 } } });
      try {
        await shipmentService.createShipmentForOrder(order.orderNumber);
        const sent = spy.mock.calls[0][0];
        expect(sent.weightGrams).toBe(800); // 400 g x 2 units, instead of the 250 g default
        expect(sent.dimensions).toEqual({ length: 12, breadth: 8, height: 12 }); // two 6 cm units stacked
      } finally {
        await Product.updateOne({ _id: product._id }, { $set: { parcel: original?.parcel || {} } });
      }
    });

    it("saves a product's parcel from the admin form, turning blanks and junk into not-set", async () => {
      const temp = await Product.create({ name: `Parcel ${stamp}`, slug: `parcel-${stamp}`, sku: `PARCEL-${stamp}`, categoryId: "ayurvedic-herbs", status: "active", basePricePaise: 10000 });
      try {
        const out = await adminService.updateProduct(String(temp._id), { parcel: { weightGrams: "300", lengthCm: "10.5", breadthCm: "", heightCm: "abc" } }, null);
        expect(out.parcel).toMatchObject({ weightGrams: 300, lengthCm: 10.5, breadthCm: null, heightCm: null });
        const saved = await Product.findById(temp._id).lean();
        expect(saved.parcel.weightGrams).toBe(300);
        expect(saved.parcel.breadthCm).toBeNull();
      } finally {
        await ProductVariant.deleteMany({ productId: temp._id });
        await Product.deleteOne({ _id: temp._id });
      }
    });

    it("keeps the courier's default box when no product has box sizes", async () => {
      const spy = vi.spyOn(shiprocket, "createShipment").mockResolvedValue({
        shiprocketOrderId: "sr-q", shipmentId: "ship-q", awbCode: `AWB-Q-${stamp}`, courierName: "Delhivery", courierId: "5", trackingUrl: "", labelUrl: "", pickupRequested: true,
      });
      const { order } = await makeOrder({ paymentMethod: "Cash on Delivery (COD)", status: ORDER_STATUS.CONFIRMED });
      await shipmentService.createShipmentForOrder(order.orderNumber);
      const sent = spy.mock.calls[0][0];
      expect(sent.dimensions).toBeUndefined();
      expect(sent.weightGrams).toBe(250);
    });
  });

  describe("Shiprocket order payload", () => {
    const run = async (orderData) => {
      const adapter = new ShiprocketAdapter();
      adapter.isMock = false;
      adapter.cachedToken = "token";
      adapter.cachedTokenExpiresAt = Date.now() + 100000;
      const sent = [];
      vi.stubGlobal("fetch", async (url, init) => {
        sent.push({ url, body: init?.body ? JSON.parse(init.body) : null });
        if (String(url).includes("orders/create/adhoc")) {
          return new Response(JSON.stringify({ order_id: 11, shipment_id: 22 }), { status: 200 });
        }
        if (String(url).includes("assign/awb")) {
          return new Response(JSON.stringify({ response: { data: { awb_code: "AWB123", courier_name: "Delhivery", courier_company_id: 5 } } }), { status: 200 });
        }
        return new Response(JSON.stringify({ label_url: "https://x/label.pdf" }), { status: 200 });
      });
      const result = await adapter.createShipment(orderData);
      vi.unstubAllGlobals();
      return { result, sent };
    };

    const base = {
      orderNumber: "DA-PAYLOAD-1",
      items: [{ name: "Shilajit", sku: "SKU1", quantity: 2, unitPricePaise: 49900 }],
      customer: { name: "A", email: "a@example.test", phone: "+91 98765 43210" },
      shippingAddress: { fullName: "A B", street: "1 Street", city: "Pune", state: "Maharashtra", pincode: "411001", phone: "9876543210" },
      pricing: { subtotalPaise: 119800, shippingPaise: 5000, totalPaise: 94800 },
      weightGrams: 500,
    };

    it("sends a COD order as COD with the amount the courier must collect", async () => {
      const { result, sent } = await run({ ...base, paymentMethod: "Cash on Delivery (COD)" });
      const body = sent.find((s) => s.url.includes("orders/create/adhoc")).body;
      expect(body.payment_method).toBe("COD");
      expect(body.order_items[0].selling_price).toBe(499);
      expect(body.order_items[0].units).toBe(2);
      expect(body.sub_total + body.shipping_charges - body.total_discount).toBeCloseTo(948, 2);
      expect(body.pickup_location).toBe(config.SHIPROCKET_PICKUP_LOCATION);
      expect(body.order_date).toMatch(/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/);
      expect(body.billing_phone).toBe("9876543210");
      expect(body.weight).toBe(0.5);
      expect(result.awbCode).toBe("AWB123");
    });

    it("sends an online-paid order as Prepaid", async () => {
      const { sent } = await run({ ...base, paymentMethod: "Online Payment" });
      expect(sent.find((s) => s.url.includes("orders/create/adhoc")).body.payment_method).toBe("Prepaid");
    });

    it("refuses an item without a valid price", async () => {
      await expect(run({ ...base, paymentMethod: "Online Payment", items: [{ name: "X", sku: "S", quantity: 1 }] })).rejects.toThrow(/valid price/i);
    });
  });
});
