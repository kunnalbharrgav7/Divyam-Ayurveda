import { verifyAccessToken } from "../utils/token.js";
import { ApiError } from "../utils/apiError.js";
import { User } from "../models/User.js";
import { asyncHandler } from "../utils/asyncHandler.js";

export const authenticate = asyncHandler(async (req, res, next) => {
  const authHeader = req.headers.authorization;
  let token = null;

  if (authHeader && authHeader.startsWith("Bearer ")) {
    token = authHeader.split(" ")[1];
  } else if (req.cookies && req.cookies.accessToken) {
    token = req.cookies.accessToken;
  }

  if (!token) {
    throw ApiError.unauthorized("Authentication required. Please provide a Bearer access token.");
  }

  const decoded = verifyAccessToken(token);

  const user = await User.findById(decoded.id).populate("roles");
  if (!user) {
    throw ApiError.unauthorized("User account associated with this token no longer exists.");
  }

  // A token issued before the last email/password change (or from before sessions were versioned: no "tv") is dead
  if ((decoded.tv ?? 0) !== (user.tokenVersion ?? 0)) {
    throw ApiError.unauthorized("Your session has ended. Please sign in again.");
  }

  if (user.status !== "active") {
    throw ApiError.forbidden("This account is currently suspended or inactive.");
  }

  if (user.lockUntil && user.lockUntil > new Date()) {
    throw ApiError.forbidden("This account is temporarily locked due to excessive failed attempts.");
  }

  req.user = user;
  next();
});

export const optionalAuthenticate = asyncHandler(async (req, res, next) => {
  // The header token and the session cookie are both the customer's own session: if one is stale (an access token
  // only lives a few minutes) the other still counts, so a signed-in customer is never silently treated as a guest.
  const authHeader = req.headers.authorization;
  const candidates = [];
  if (authHeader && authHeader.startsWith("Bearer ")) candidates.push(authHeader.split(" ")[1]);
  if (req.cookies && req.cookies.accessToken && !candidates.includes(req.cookies.accessToken)) candidates.push(req.cookies.accessToken);

  req.user = null;
  for (const token of candidates) {
    try {
      const decoded = verifyAccessToken(token);
      const user = await User.findById(decoded.id).populate("roles");
      if (user && user.status === "active" && (decoded.tv ?? 0) === (user.tokenVersion ?? 0)) {
        req.user = user;
        break;
      }
    } catch {
      // try the next one
    }
  }

  next();
});

export const requireStaff = asyncHandler(async (req, res, next) => {
  if (!req.user) {
    throw ApiError.unauthorized("Staff authentication required.");
  }

  if (!req.user.isStaff) {
    throw ApiError.forbidden("Access restricted to authorized store staff.");
  }

  if (req.user.status !== "active") {
    throw ApiError.forbidden("Staff account is not active.");
  }

  next();
});

