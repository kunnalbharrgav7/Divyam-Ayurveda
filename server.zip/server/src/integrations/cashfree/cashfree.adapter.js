import { config, IS_DEPLOYED } from "../../config/index.js";
import { logger } from "../../config/logger.js";
import { verifyHmacSignature, sha256 } from "../../utils/crypto.js";
import { toRupees } from "../../utils/currency.js";
import { ApiError } from "../../utils/apiError.js";
import { CashfreeMock } from "./cashfree.mock.js";

const REQUEST_TIMEOUT_MS = 20000;
// How long a customer has to pay before the order is cancelled and its stock released
export const PAYMENT_WINDOW_MS = 2 * 60 * 60 * 1000;

export class CashfreeAdapter {
  constructor() {
    this.appId = config.CASHFREE_APP_ID;
    this.secretKey = config.CASHFREE_SECRET_KEY;
    this.apiVersion = config.CASHFREE_API_VERSION || "2025-01-01";
    this.baseUrl =
      config.CASHFREE_ENV === "production"
        ? "https://api.cashfree.com/pg"
        : "https://sandbox.cashfree.com/pg";

    this.isMock = config.NODE_ENV === "test" || !this.appId || this.appId === "TEST_CF_APP_ID";
    // Live server (NODE_ENV=production, or on Render): never fall back to fake results
    if (IS_DEPLOYED && this.isMock) {
      throw new Error("Cannot run Cashfree mock payment adapter in production environment. Valid CASHFREE_APP_ID and CASHFREE_SECRET_KEY required.");
    }
    this.mock = new CashfreeMock();
    if (!IS_DEPLOYED && !this.isMock && config.CASHFREE_ENV === "production") {
      logger.warn("This is a local run, but it is using your LIVE Cashfree keys: every online order you place here creates a real payment order at Cashfree. Use sandbox keys (CASHFREE_ENV=sandbox) for local work.");
    }
    // Live Cashfree rejects payment orders whose callback or return address is not public https. Say so loudly at
    // startup instead of letting every customer's payment fail one by one.
    if (IS_DEPLOYED && !this.isMock && config.CASHFREE_ENV === "production") {
      if (!/^https:\/\//i.test(config.CASHFREE_WEBHOOK_URL || "")) {
        logger.error({ webhookUrl: config.CASHFREE_WEBHOOK_URL }, "CASHFREE_WEBHOOK_URL must be a public https address (https://<your-api>/api/v1/webhooks/cashfree) or live payments will be refused");
      }
      if (!/^https:\/\//i.test(config.CLIENT_ORIGIN || "")) {
        logger.error({ clientOrigin: config.CLIENT_ORIGIN }, "CLIENT_ORIGIN must be your https storefront address (e.g. https://divyamayurveda.in) or live payments will be refused");
      }
    }
    logger.info({ mode: this.isMock ? "MOCK (fake payments)" : `LIVE API (${config.CASHFREE_ENV})`, apiVersion: this.apiVersion, webhookUrl: config.CASHFREE_WEBHOOK_URL }, "Cashfree adapter ready");
  }

  /**
   * Create Cashfree Order and Payment Session
   */
  async createPaymentSession({ orderNumber, amountPaise, customer, returnUrl }) {
    if (this.isMock) {
      logger.info({ orderNumber, amountPaise }, "Using Cashfree Mock Adapter");
      return this.mock.createPaymentSession({ orderNumber, amountPaise, customer, returnUrl });
    }

    const rawId = String(customer?.id || customer?._id || customer?.email || "guest").replace(/[^a-zA-Z0-9_-]/g, "_");
    const customerId = rawId.length >= 3 ? rawId.slice(0, 50) : `cust_${rawId}`;
    const customerPhone = String(customer?.phone || "").replace(/[^0-9]/g, "").slice(-10);
    if (customerPhone.length !== 10) {
      throw ApiError.badRequest("A valid 10-digit mobile number is required for online payment.");
    }
    if (!customer?.email) {
      throw ApiError.badRequest("An email address is required for online payment.");
    }
    const webhookUrl =
      config.CASHFREE_WEBHOOK_URL || `${config.API_URL.replace(/\/+$/, "")}/api/v1/webhooks/cashfree`;

    const payload = {
      order_id: String(orderNumber).trim(),
      order_amount: Number(toRupees(amountPaise)),
      order_currency: "INR",
      customer_details: {
        customer_id: customerId,
        customer_email: customer.email,
        customer_phone: customerPhone,
        customer_name: customer?.name || "Customer",
      },
      order_meta: {
        return_url:
          returnUrl ||
          `${config.CLIENT_ORIGIN.replace(/\/+$/, "")}/order-confirmation/${orderNumber}?order_id={order_id}`,
        notify_url: webhookUrl,
      },
      // Unpaid orders are cancelled and their stock released after this window (see expireUnpaidOrders)
      order_expiry_time: new Date(Date.now() + PAYMENT_WINDOW_MS).toISOString(),
    };

    try {
      const response = await fetch(`${this.baseUrl}/orders`, {
        method: "POST",
        headers: {
          "x-client-id": this.appId,
          "x-client-secret": this.secretKey,
          "x-api-version": this.apiVersion,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });

      const data = await response.json();
      if (!response.ok) {
        // Paying again (retry, double click, back button) re-uses the order Cashfree already holds
        if (response.status === 409 || data.code === "order_already_exists") {
          const existing = await this.getOrderStatus(orderNumber);
          if (existing.orderStatus === "ACTIVE" && existing.paymentSessionId) {
            return {
              paymentSessionId: existing.paymentSessionId,
              orderId: existing.orderId,
              cfOrderId: existing.cfOrderId,
              environment: config.CASHFREE_ENV,
            };
          }
          throw ApiError.conflict(
            existing.orderStatus === "PAID"
              ? "This order has already been paid."
              : "The payment window for this order has closed. Please place a new order."
          );
        }
        logger.error({ data, orderNumber }, "Cashfree PG create order returned error");
        throw new Error(data.message || "Failed to initialize Cashfree payment session");
      }

      return {
        paymentSessionId: data.payment_session_id,
        orderId: data.order_id,
        cfOrderId: data.cf_order_id,
        environment: config.CASHFREE_ENV,
      };
    } catch (err) {
      logger.error({ err: err.message, orderNumber }, "Cashfree API request exception");
      throw err;
    }
  }

  /**
   * Fetch order status from Cashfree server
   */
  async getOrderStatus(orderNumber) {
    if (this.isMock) {
      return this.mock.getOrderStatus(orderNumber);
    }

    try {
      const response = await fetch(`${this.baseUrl}/orders/${encodeURIComponent(orderNumber)}`, {
        headers: {
          "x-client-id": this.appId,
          "x-client-secret": this.secretKey,
          "x-api-version": this.apiVersion,
        },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.message || "Failed to fetch Cashfree order status");
      }

      return {
        orderId: data.order_id,
        cfOrderId: data.cf_order_id,
        paymentSessionId: data.payment_session_id,
        orderStatus: data.order_status, // PAID, ACTIVE, EXPIRED
        orderAmount: data.order_amount,
        payments: data.payments || [],
      };
    } catch (err) {
      logger.error({ err: err.message, orderNumber }, "Cashfree status check failed");
      throw err;
    }
  }

  /**
   * Fetch payment attempts from Cashfree for an order
   */
  async getOrderPayments(orderNumber) {
    if (this.isMock) {
      return this.mock.getOrderPayments ? this.mock.getOrderPayments(orderNumber) : [];
    }

    try {
      const response = await fetch(`${this.baseUrl}/orders/${encodeURIComponent(orderNumber)}/payments`, {
        headers: {
          "x-client-id": this.appId,
          "x-client-secret": this.secretKey,
          "x-api-version": this.apiVersion,
        },
        signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
      });

      const data = await response.json();
      if (!response.ok) {
        return [];
      }

      return Array.isArray(data) ? data : [];
    } catch (err) {
      logger.warn({ err: err.message, orderNumber }, "Cashfree get payments warning");
      return [];
    }
  }

  /**
   * Refund (part of) a paid order back to the customer's original payment method.
   */
  async createRefund({ orderNumber, refundId, amountPaise, note = "" }) {
    if (this.isMock) {
      logger.info({ orderNumber, refundId, amountPaise }, "Using Cashfree Mock Adapter (refund)");
      return this.mock.createRefund({ orderNumber, refundId, amountPaise });
    }

    const response = await fetch(`${this.baseUrl}/orders/${encodeURIComponent(orderNumber)}/refunds`, {
      method: "POST",
      headers: {
        "x-client-id": this.appId,
        "x-client-secret": this.secretKey,
        "x-api-version": this.apiVersion,
        "x-idempotency-key": refundId,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        refund_amount: Number(toRupees(amountPaise)),
        refund_id: refundId,
        refund_note: note.slice(0, 100),
        refund_speed: "STANDARD",
      }),
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      logger.error({ data, orderNumber, refundId }, "Cashfree refund request failed");
      throw new Error(data.message || "Cashfree rejected the refund request.");
    }
    return { refundId: data.refund_id, cfRefundId: data.cf_refund_id, status: data.refund_status, raw: data };
  }

  /** Current status of a refund at Cashfree */
  async getRefund({ orderNumber, refundId }) {
    if (this.isMock) return this.mock.getRefund({ refundId });

    const response = await fetch(
      `${this.baseUrl}/orders/${encodeURIComponent(orderNumber)}/refunds/${encodeURIComponent(refundId)}`,
      { headers: { "x-client-id": this.appId, "x-client-secret": this.secretKey, "x-api-version": this.apiVersion } }
    );
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "Could not fetch the refund status from Cashfree.");
    return { refundId: data.refund_id, cfRefundId: data.cf_refund_id, status: data.refund_status, raw: data };
  }

  /**
   * Verify Cashfree Webhook Signature (supports both Hex and Base64 signatures)
   */
  verifyWebhookSignature(rawBody, headers) {
    const signature = headers["x-webhook-signature"] || headers["x-cashfree-signature"];
    const timestamp = headers["x-webhook-timestamp"] || "";

    if (!signature) {
      return false;
    }

    const payloadToSign = `${timestamp}${rawBody}`;
    const secret = this.secretKey || config.CASHFREE_SECRET_KEY || "TEST_CF_SECRET_KEY";
    return verifyHmacSignature(payloadToSign, signature, secret);
  }
}

export const cashfree = new CashfreeAdapter();
