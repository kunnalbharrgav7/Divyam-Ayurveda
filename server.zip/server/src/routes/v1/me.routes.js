import { Router } from "express";
import { authenticate } from "../../middleware/auth.js";
import { validate } from "../../middleware/validate.js";
import * as authController from "../../controllers/auth.controller.js";
import * as orderController from "../../controllers/order.controller.js";
import * as cartController from "../../controllers/cart.controller.js";
import * as returnController from "../../controllers/return.controller.js";
import * as cancellationController from "../../controllers/cancellation.controller.js";
import * as contentController from "../../controllers/content.controller.js";
import { ticketLimiter, credentialLimiter } from "../../middleware/rateLimiter.js";
import { addressSchema, changePasswordSchema, changePhoneSchema } from "../../validators/auth.validator.js";
import { ticketCreateSchema, ticketMessageSchema } from "../../validators/support.validator.js";

const router = Router();

router.use(authenticate);

// Profile
router.get("/", authController.getProfile);
router.patch("/", authController.updateProfile);
router.patch("/password", validate(changePasswordSchema), authController.changePassword);
router.patch("/phone", credentialLimiter, validate(changePhoneSchema), authController.changePhone);

// Addresses
router.get("/addresses", authController.getAddresses);
router.post("/addresses", validate(addressSchema), authController.addAddress);
router.patch("/addresses/:addressId", authController.updateAddress);
router.delete("/addresses/:addressId", authController.deleteAddress);
router.patch("/addresses/:addressId/default", authController.setDefaultAddress);

// Contact Us messages sent while signed in, with the team's replies
router.get("/enquiries", contentController.listMyEnquiries);

// Support tickets: customers see and write to their own only
router.get("/tickets", contentController.listMyTickets);
router.post("/tickets", ticketLimiter, validate(ticketCreateSchema), contentController.createMyTicket);
router.get("/tickets/:ticketNumber", contentController.getMyTicket);
router.post("/tickets/:ticketNumber/messages", ticketLimiter, validate(ticketMessageSchema), contentController.addMyTicketMessage);

// Customer Reviews
router.get("/reviews", orderController.getMyReviews);

// Returns, refunds & store credit
router.get("/return-options", returnController.getReturnOptions);
router.get("/returns/eligibility", returnController.getEligibilityMap);
router.get("/returns", returnController.listMyReturns);
router.get("/returns/:id", returnController.getMyReturn);
router.post("/returns/:id/cancel", returnController.cancelMyReturn);
router.get("/orders/:orderNumber/return-eligibility", returnController.getEligibility);
router.post("/orders/:orderNumber/returns", returnController.createReturn);
router.get("/store-credit", returnController.getStoreCredit);

// Customer Orders
router.get("/orders", orderController.getMyOrders);
router.get("/orders/:orderNumber", orderController.getMyOrder);
router.get("/orders/:orderNumber/invoice", orderController.getInvoice);
router.get("/cancellations", cancellationController.listMyCancellations);

// Customer Cart
router.get("/cart", cartController.getCart);
router.post("/cart/items", cartController.addItem);
router.patch("/cart/items/:variantId", cartController.updateItem);
router.delete("/cart/items/:variantId", cartController.removeItem);
router.delete("/cart", cartController.clearCart);

export default router;

