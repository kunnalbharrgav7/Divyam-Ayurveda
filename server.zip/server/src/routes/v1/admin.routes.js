import { Router } from "express";
import * as adminController from "../../controllers/admin.controller.js";
import * as orderController from "../../controllers/order.controller.js";
import * as returnController from "../../controllers/return.controller.js";
import * as cancellationController from "../../controllers/cancellation.controller.js";
import { authenticate, requireStaff } from "../../middleware/auth.js";
import { requirePermission, requirePasswordChanged, requireOwner } from "../../middleware/rbac.js";
import { PERMISSIONS } from "../../constants/permissions.js";
import { requireIdempotency } from "../../middleware/idempotency.js";
import { auditAdminMutations } from "../../middleware/auditContext.js";
import * as authController from "../../controllers/auth.controller.js";
import { validate } from "../../middleware/validate.js";
import { credentialLimiter } from "../../middleware/rateLimiter.js";
import { adminChangeEmailSchema, adminChangePasswordSchema } from "../../validators/auth.validator.js";

const router = Router();

// Staff authentication guard for all admin routes
router.use(authenticate, requireStaff, requirePasswordChanged, auditAdminMutations);

// The signed-in staff member's own profile and sign-in credentials (any staff role may manage their own)
router.get("/profile", authController.getAdminProfile);
router.patch("/profile/email", credentialLimiter, validate(adminChangeEmailSchema), authController.updateAdminEmail);
router.patch("/profile/password", credentialLimiter, validate(adminChangePasswordSchema), authController.updateAdminPassword);

// Dashboard & Analytics
router.get("/dashboard", requirePermission(PERMISSIONS.REPORTS_VIEW), adminController.getDashboard);
router.get("/reports/revenue", requirePermission(PERMISSIONS.REPORTS_VIEW), adminController.getRevenueReport);
router.get("/reports/sales", requirePermission(PERMISSIONS.REPORTS_VIEW), adminController.getSalesReport);

// Catalog: Products & Inventory
router.get("/products", requirePermission(PERMISSIONS.PRODUCTS_VIEW), adminController.listAdminProducts);
router.post("/products", requirePermission(PERMISSIONS.PRODUCTS_CREATE), adminController.createProduct);
router.patch("/products/:id", requirePermission(PERMISSIONS.PRODUCTS_EDIT), adminController.updateProduct);
router.delete("/products/:id", requirePermission(PERMISSIONS.PRODUCTS_DELETE), adminController.deleteProduct);

router.post(
  "/inventory/adjustments",
  requirePermission(PERMISSIONS.INVENTORY_MANAGE),
  requireIdempotency(false),
  adminController.adjustInventory
);

// Catalog: Categories, Brands, Collections
router.get("/categories", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.listCategories);
router.post("/categories", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.createCategory);
router.patch("/categories/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.updateCategory);
router.delete("/categories/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.deleteCategory);

router.get("/brands", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.listBrands);
router.post("/brands", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.createBrand);
router.patch("/brands/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.updateBrand);
router.delete("/brands/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.deleteBrand);

router.get("/collections", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.listCollections);
router.post("/collections", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.createCollection);
router.patch("/collections/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.updateCollection);
router.delete("/collections/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.deleteCollection);

router.get("/ingredients", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.listAdminIngredients);
router.post("/ingredients", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.createIngredient);
router.patch("/ingredients/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.updateIngredient);
router.delete("/ingredients/:id", requirePermission(PERMISSIONS.CATEGORIES_MANAGE), adminController.deleteIngredient);

// Orders & Shipments
router.get("/orders", requirePermission(PERMISSIONS.ORDERS_VIEW), adminController.listAdminOrders);
router.get("/orders/:orderNumber", requirePermission(PERMISSIONS.ORDERS_VIEW), adminController.getAdminOrder);
router.patch("/orders/:orderNumber/status", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.updateOrderStatus);
router.patch("/orders/:orderNumber/payment-status", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.updatePaymentStatus);
router.post("/orders/:orderNumber/shipments", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.createShipment);
router.post("/orders/:orderNumber/shipments/retry-fulfilment", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.retryFulfilment);
router.post("/orders/:orderNumber/shipments/advance", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.advanceShipment);
router.patch("/orders/:orderNumber/tracking", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.updateOrderTracking);
router.get("/orders/:orderNumber/shipment", requirePermission(PERMISSIONS.ORDERS_VIEW), adminController.getOrderShipment);
router.get("/orders/:orderNumber/shipment/live", requirePermission(PERMISSIONS.ORDERS_VIEW), adminController.getLiveShipmentTracking);
router.post("/orders/:orderNumber/cancel", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.cancelOrder);
router.get("/orders/:orderNumber/invoice", requirePermission(PERMISSIONS.ORDERS_VIEW), orderController.getInvoice);
router.post("/orders/:orderNumber/notes", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.addOrderNote);
router.post("/orders/:orderNumber/tracking-code", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.regenerateOrderTrackingCode);
router.delete("/orders/:orderNumber/tracking-code", requirePermission(PERMISSIONS.ORDERS_UPDATE), adminController.revokeOrderTrackingCode);

// Returns & Refunds
router.get("/returns", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.listAdminReturns);
router.get("/returns/:id", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.getAdminReturn);
router.post("/returns/:id/approve", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.approveReturn);
router.post("/returns/:id/reject", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.rejectReturn);
router.post("/returns/:id/receive", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.receiveReturn);
router.post("/returns/:id/refund", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.refundReturn);
router.post("/returns/:id/refund/refresh", requirePermission(PERMISSIONS.REFUNDS_MANAGE), returnController.refreshReturnRefund);

// Order Cancellations & Gateway Refunds
router.get("/cancellations", requirePermission(PERMISSIONS.ORDERS_VIEW), cancellationController.listAdminCancellations);
router.get("/cancellations/:id", requirePermission(PERMISSIONS.ORDERS_VIEW), cancellationController.getAdminCancellation);
router.post("/cancellations/:id/approve", requirePermission(PERMISSIONS.ORDERS_UPDATE), cancellationController.approveCancellation);
router.post("/cancellations/:id/reject", requirePermission(PERMISSIONS.ORDERS_UPDATE), cancellationController.rejectCancellation);
router.get("/refunds", requirePermission(PERMISSIONS.REFUNDS_MANAGE), cancellationController.listAdminRefunds);
router.post("/refunds/:id/retry", requirePermission(PERMISSIONS.REFUNDS_MANAGE), cancellationController.retryAdminRefund);
router.get("/cancellation-settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), cancellationController.getCancellationSettings);
router.patch("/cancellation-settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), cancellationController.updateCancellationSettings);

// Coupons
router.get("/coupons", requirePermission(PERMISSIONS.DISCOUNTS_MANAGE), adminController.listCoupons);
router.post("/coupons", requirePermission(PERMISSIONS.DISCOUNTS_MANAGE), adminController.createCoupon);
router.patch("/coupons/:id", requirePermission(PERMISSIONS.DISCOUNTS_MANAGE), adminController.updateCoupon);
router.delete("/coupons/:id", requirePermission(PERMISSIONS.DISCOUNTS_MANAGE), adminController.deleteCoupon);

// Referrals & Rewards Program
router.get("/referrals", requirePermission(PERMISSIONS.CUSTOMERS_VIEW), adminController.listReferrals);
router.get("/referrals/settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), adminController.getReferralProgram);
router.put("/referrals/settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), adminController.updateReferralProgram);
router.get("/referrals/export", requirePermission(PERMISSIONS.CUSTOMERS_VIEW), adminController.exportReferrals);
router.post("/referrals/:id/approve", requirePermission(PERMISSIONS.CUSTOMERS_MANAGE), adminController.approveReferral);
router.post("/referrals/:id/void", requirePermission(PERMISSIONS.CUSTOMERS_MANAGE), adminController.voidReferral);

// Review Moderation
router.get("/reviews", requirePermission(PERMISSIONS.REVIEWS_MODERATE), adminController.listAdminReviews);
router.patch("/reviews/:id", requirePermission(PERMISSIONS.REVIEWS_MODERATE), adminController.moderateReview);
router.delete("/reviews/:id", requirePermission(PERMISSIONS.REVIEWS_MODERATE), adminController.deleteReview);

// Customer Support & Communications
router.get("/enquiries", requirePermission(PERMISSIONS.SUPPORT_MANAGE), adminController.listEnquiries);
router.get("/support-tickets", requirePermission(PERMISSIONS.SUPPORT_MANAGE), adminController.listSupportTickets);
router.patch("/enquiries/:id", requirePermission(PERMISSIONS.SUPPORT_MANAGE), adminController.updateEnquiry);
router.patch("/support-tickets/:id", requirePermission(PERMISSIONS.SUPPORT_MANAGE), adminController.updateSupportTicket);

// Storefront Content & Settings
router.get("/homepage", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.getHomepageAdmin);
router.patch("/homepage", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.updateHomepageAdmin);
router.get("/content-pages", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.listContentPages);
router.put("/content-pages/:slug", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.updateContentPage);
router.get("/faqs", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.listAdminFaqs);
router.post("/faqs", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.createFaq);
router.patch("/faqs/:id", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.updateFaq);
router.delete("/faqs/:id", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.deleteFaq);
router.get("/blog", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.listAdminBlogPosts);
router.post("/blog", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.createBlogPost);
router.patch("/blog/:id", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.updateBlogPost);
router.delete("/blog/:id", requirePermission(PERMISSIONS.CONTENT_MANAGE), adminController.deleteBlogPost);
router.get("/system/integrations", requirePermission(PERMISSIONS.SETTINGS_MANAGE), adminController.getIntegrationStatus);
router.get("/settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), adminController.getSettings);
router.patch("/settings", requirePermission(PERMISSIONS.SETTINGS_MANAGE), adminController.updateSettings);

// Customers & Staff
router.get("/customers", requirePermission(PERMISSIONS.CUSTOMERS_VIEW), adminController.listCustomers);
router.get("/customers/:id", requirePermission(PERMISSIONS.CUSTOMERS_VIEW), adminController.getCustomer);
router.patch("/customers/:id", requirePermission(PERMISSIONS.CUSTOMERS_MANAGE), adminController.updateCustomerStatus);
router.post("/customers/:id/notes", requirePermission(PERMISSIONS.CUSTOMERS_MANAGE), adminController.addCustomerNote);
router.get("/users", requireOwner, requirePermission(PERMISSIONS.USERS_MANAGE), adminController.listAdminUsers);
router.post("/users", requireOwner, requirePermission(PERMISSIONS.USERS_MANAGE), adminController.createAdminUser);
router.patch("/users/:id", requireOwner, requirePermission(PERMISSIONS.USERS_MANAGE), adminController.updateAdminUser);
router.delete("/users/:id", requireOwner, requirePermission(PERMISSIONS.USERS_MANAGE), adminController.deleteAdminUser);
router.post("/users/:id/reset-password", credentialLimiter, requireOwner, requirePermission(PERMISSIONS.USERS_MANAGE), adminController.resetAdminUserPassword);
router.get("/audit-logs", requirePermission(PERMISSIONS.AUDIT_VIEW), adminController.listAuditLogs);

export default router;

